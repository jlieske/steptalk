/**
    MyLanguageEngine
 
    @COPYRIGHT@
 
    Written by: @AUTHOR@
    Date: @DATE@
 
 */

#import "MyLanguageEngine.h"

@implementation MyLanguageEngine
- (id) executeCode:(NSString *)sourceCode 
       inEnvironment:(STEnvironment *)env
{
    id                     retval = nil;

    /* execute the code sourceCode using environment env */
    /* use [env objectDictionary] to get environment objects 
       (see STEnvironment.h to see what you can do) */
    
    /*    retval = return value from the interpreter; */
    
    return retval;
}
@end
