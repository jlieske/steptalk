/**
    MyLanguageEngine
 
    @COPYRIGHT@
 
    Written by: @AUTHOR@
    Date: @DATE@
 
 */

#import <StepTalk/STEngine.h>

@interface MyLanguageEngine:STEngine
{
}
@end
